USE NURX;
DELETE from NURX.patches WHERE id = 4;
DELETE from NURX.patches WHERE id = 9;
DROP TABLE IF EXISTS dept_emp,
                     dept_manager,
                     titles,
                     salaries, 
                     employees, 
                     departments;