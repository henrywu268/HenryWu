package com.nurx.db.utils;

import java.io.File;

/**
 * A tester for the CryptoUtils class.
 * @author www.codejava.net
 *
 */
public class CryptoUtilsTest {
    public static void main(String[] args) throws Exception {
//        String key = "Mary has one cat1";
//        File inputFile = new File("sql/document.txt");
//        File encryptedFile = new File("document.encrypted");
//        File decryptedFile = new File("document.decrypted");
//         
//        try {
//            CryptoUtils.encrypt(key, inputFile, encryptedFile);
//            CryptoUtils.decrypt(key, encryptedFile, decryptedFile);
//        } catch (CryptoException ex) {
//            System.out.println(ex.getMessage());
//            ex.printStackTrace();
//        }
    	String release1 =  "Release-1.50";
    	String release2 =  "Release-1.19";
    	if(release1.compareTo(release2)>0) {
    		System.out.println(release1);
    	} else {
    		System.out.println(release2);
    	}
    	Runtime.getRuntime().exec("pwd");
    }
}