USE NURX;
ALTER TABLE employees ADD COLUMN  emp_annual_clearence_date date NULL AFTER  last_name;