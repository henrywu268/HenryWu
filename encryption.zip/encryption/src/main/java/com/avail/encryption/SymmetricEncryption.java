package com.avail.encryption;


import java.security.SecureRandom;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec; 

/**
 * Creating the symmetric class which implements encryption
 * 
 * @author yuewu
 *
 */
public class SymmetricEncryption { 

	private static final String AES = "AES"; 

	// Using a Block cipher(CBC mode) 
	private static final String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5PADDING"; 

	/**
	 * Function to create a secret key 
	 * @return SecretKey
	 * @throws Exception
	 */
	public SecretKey createAESKey() throws Exception 
	{ 
		SecureRandom securerandom = new SecureRandom(); 
		KeyGenerator keygenerator = KeyGenerator.getInstance(AES); 
		keygenerator.init(256, securerandom); 
		SecretKey key = keygenerator.generateKey(); 
        return key; 
	} 

	/**
	 * Function to initialize a vector with an arbitrary value
	 * @return byte[] array
	 */
	public byte[] createInitializationVector() 
	{
		// Used with encryption 
		byte[] initializationVector = new byte[16]; 
		SecureRandom secureRandom = new SecureRandom(); 
		secureRandom.nextBytes(initializationVector); 
		return initializationVector; 
	} 

	/**
	 * This function convert plain text to cipher text.
	 * @param plainText
	 * @param secretKey
	 * @param initializationVector
	 * @return byte[] array
	 * @throws Exception
	 */
	public byte[] doEncryption(String plainText, SecretKey secretKey, byte[] initializationVector) throws Exception 
	{   
		Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM); 
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector); 
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec); 
		return cipher.doFinal(plainText.getBytes()); 
	} 

	/**
	 * This function converts cipher text to the plain text using the key.
	 * @param cipherText
	 * @param secretKey
	 * @param initializationVector
	 * @return
	 * @throws Exception
	 */
	public String doDecryption(byte[] cipherText, SecretKey secretKey, byte[] initializationVector) throws Exception 
	{ 
		Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM); 
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector); 
		cipher.init( Cipher.DECRYPT_MODE, secretKey, ivParameterSpec); 
		byte[] result = cipher.doFinal(cipherText); 
		return new String(result); 
	} 
	
	/**
	 * 
	 * @param phrase
	 * @param secretKey
	 * @param initializationVector
	 * @return Map of key and value pair, 
	 * key is the text to be encrypt and value is the text to be encrypted
	 * @throws Exception
	 */
	public Map<String, String> doPhraseEncryption(String phrase, SecretKey secretKey, byte[] initializationVector) throws Exception 
	{
		/**
		 * encryption result saved in HashMap with key as to be encrypted
		 * and value as encrypted test
		 */
		Map<String, String> map = new LinkedHashMap<>();
		
		/**
		 * 1st step to encrypt original phrase
		 */
		String[] stringArray = phrase.split(" ");
		StringBuilder encryptedString = new StringBuilder();
		for(int i=0; i<stringArray.length; i++) {
			encryptedString.append(doEncryption(stringArray[i], secretKey, initializationVector) + " ");
		}

		/**
		 * 2nd step, encrypt pass 2 until there is a single encrypted 
		 * string that represents the sentence
		 */
		map.put(phrase, encryptedString.toString().trim());
		while(encryptedString.toString().split(" ").length>1) {
			stringArray = encryptedString.toString().split(" ");
			StringBuilder value = new StringBuilder();
	        for(int i=0; i<stringArray.length; i++) {
	        	if(i+1 < stringArray.length)
	        		value.append(doEncryption(stringArray[i] + " " + stringArray[++i], secretKey, initializationVector) + " ");
	        	else
	        		value.append(doEncryption(stringArray[i], secretKey, initializationVector));
	        }
			map.put(encryptedString.toString(), value.toString().trim());
			encryptedString = new StringBuilder(value.toString().trim());
		}
		int i = 0; //count number of pass
		for(String stringElement : map.values()) {
			i++;
			System.out.println("Encrypted pass " + i + " result " + stringElement);
		}
		System.out.println();
		return map;
	}

	/**
	 * 
	 * @param String phrase
	 * @return boolean
     *
	 * Take in a phrase no longer than 7 words and only alphabets and space. No punctuation.
	 * 
	 */
	public boolean validateInputPhrase(String phrase) {
        String pattern = "[a-zA-Z\\s]+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(phrase);
        if(m.matches() && phrase.split(" ").length<=7) {
        	return true;
        } else {
        	return false;
        }
	}
	
	public static void main(String args[]) throws Exception 
	{   
		SymmetricEncryption se = new SymmetricEncryption();
		SecretKey Symmetrickey = se.createAESKey(); 
		byte[] initializationVector = se.createInitializationVector(); 
//		String plainText = "The dog jumped over the fence too"; 
		String inputPhrase = "";
		System.out.println("Enter your phrase: ");
		System.out.println("Phrase can not be longer than 7 words, only alphabets and separated space. No punctuations.");
		System.out.println("Type exit to quit the program\n");
		Scanner sc = new Scanner (System.in);
		while(sc.hasNext()) {
		    inputPhrase = sc.nextLine();
		    if(("exit").equals(inputPhrase)) {
		    	break;
		    } else {
		    	if(se.validateInputPhrase(inputPhrase)) {
		    	    se.doPhraseEncryption(inputPhrase, Symmetrickey, initializationVector);
		        } else {
				    System.out.print("Phrase can not be longer than 7 words, only alphabets and separated space. No punctuations.\n\n");
		        }    
		    }
		}
        sc.close();
	} 
} 

