package com.nurx.db.patch;

import java.sql.Date;

public class PatchHistory {
	private int id;
	private Date dateApplied;
	private String status;
	private String version;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Date getDateApplied() {
		return dateApplied;
	}
	public void setDateApplied(Date dateApplied) {
		this.dateApplied = dateApplied;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "PatchHistory [id=" + id + ", dateApplied=" + dateApplied + ", status=" + status + ", version=" + version
				+ "]";
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}

}
