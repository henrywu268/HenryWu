package com.avail.encryption;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Map;

import javax.crypto.SecretKey;

import org.junit.Test;

/**
 * Unit test for Symmetric Encryption
 */
public class SymmetricEncryptionTest 
{
    /**
     * Test if SecretKey instance successfully created
     */
    @Test 
    public void createAESKeyTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();
    	try {
			se.createAESKey();
			assertTrue( se.createAESKey() instanceof SecretKey);
		} catch (Exception e) {
			fail("Symmetric Key Creation Failed");
		}
    }
    
    /**
     * Test to make sure initialization vector
     * are secure random
     */
    @Test
    public void initializationVectorTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();	
        byte[] initVectorA = se.createInitializationVector();
        byte[] initVectorB = se.createInitializationVector();
        if(!Arrays.equals(initVectorA, initVectorB)) {
        	 assertTrue( true );
        } else {
        	fail("Initialization vector is not secure random");
        }
    }
    
    /**
     * Test to make sure encryption are successful and random byte
     * arrays generated with different initialization vector are
     * not identical
     */
    @Test 
    public void doEncryptionTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();
    	try {
			SecretKey secretKey = se.createAESKey();
			byte[] initVector = se.createInitializationVector();
			byte[] encryptedBayteA = se.doEncryption("plain text", secretKey, initVector);
			initVector = se.createInitializationVector();
			byte[] encryptedBayteB = se.doEncryption("plain text", secretKey, initVector);
			if(!Arrays.equals(encryptedBayteA, encryptedBayteB)) {
	        	 assertTrue( true );
	        } else {
	        	fail("Encryption failed secure random bytes not generated successfully");
	        }
		} catch (Exception e) {
			fail("Encryption Failed");
		}
    }
    
    /**
     * Test to make sure encryption are successful and 
     * make sure final string are single encrypted string
     * 
     */
    @Test 
    public void doPhraseEncryptionTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();
    	try {
			SecretKey secretKey = se.createAESKey();
			byte[] initVector = se.createInitializationVector();
			Map<String, String> map = se.doPhraseEncryption("The dog jumped over the fence too", secretKey, initVector);
			String finalString = map.values().stream().reduce((prev, next) -> next).orElse(null);
            String [] stringArray = finalString.split(" ");
            assertTrue( stringArray.length==1 );
		} catch (Exception e) {
			fail("Encryption Failed");
		}
    }
    
    /**
     * Test input phrase 7 words and only alphabets and space. No punctuation.
     */
    @Test 
    public void validateValidInputPhraseTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();
    	assertTrue(se.validateInputPhrase("The dog jumped over the fence too"));
    	
    }
    
    /**
     * Test input phrase 7 words and only alphabets and space. With punctuation.
     */
    @Test 
    public void checkInvalidInputPhraseTest()
    {
    	SymmetricEncryption se = new SymmetricEncryption();
    	assertFalse(se.validateInputPhrase("The dog jumped over the fence too."));
    }
}
