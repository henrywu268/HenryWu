package com.nurx.db.patch;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.ibatis.jdbc.ScriptRunner;
import org.apache.log4j.Logger;

import com.nurx.db.utils.SingleFileResourceUtils;


public class NurxPatchFileRunner implements DbQueryConstants {

	// JDBC Driver Name & Database URL
	//static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; 
	static final String JDBC_DRIVER ="com.mysql.cj.jdbc.Driver";
	static final String JDBC_DB_URL = "jdbc:mysql://localhost:3306";

	// JDBC Database Credentials
	static final String JDBC_USER = "hwu";
	static final String JDBC_PASS = "password";

	public static final Logger logger = Logger.getLogger(NurxPatchFileRunner.class);

	public static void main(String[] args) {

		Connection connObj = null;
		Statement stmtOBj = null;
		try {
			/**
			 * Initialize
			 */
			String inputPhrase = "";
			Scanner sc = new Scanner (System.in);
			NurxPatchFileRunner nurxPatchRunner = new NurxPatchFileRunner();
			connObj = nurxPatchRunner.getDBConnection();
			stmtOBj = connObj.createStatement();
			
			/**
			 * Display Patches
			 */
		    System.out.println("Display patch history");
			List<PatchHistory> patchHistoryList =  nurxPatchRunner.getPatchHistory(connObj);
			patchHistoryList.forEach(System.out::println);
			
			/**
			 * Apply Patches
			 */
			nurxPatchRunner.applyPatches(nurxPatchRunner,  connObj, sc);
			
		} catch(Exception sqlException) {
			logger.error("\n=======DATABASE Exception===== " + sqlException.getMessage());
		} finally {
			try {
				if(stmtOBj != null) {
					stmtOBj.close();	// Close Statement Object
				}
				if(connObj != null) {
					connObj.close();	// Close Connection Object
				}
			} catch (Exception sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	// This Method Is Used To Print The Table Structure
	private static void showDbTableStructure() throws SQLException {
		StringBuilder builderObj = new StringBuilder();
		DatabaseMetaData metaObj = DriverManager.getConnection(JDBC_DB_URL, JDBC_USER, JDBC_PASS).getMetaData();
		ResultSet resultSetObj = metaObj.getColumns(DATABASE_NAME, null, TABLE_NAME, "%");

		builderObj.append(TABLE_NAME + " Columns Are?= (");
		while (resultSetObj.next()) {
			String columnName = resultSetObj.getString(4);
			builderObj.append(columnName).append(", ");
		}
		builderObj.deleteCharAt(builderObj.lastIndexOf(",")).deleteCharAt(builderObj.lastIndexOf(" ")).append(")").append("\n");
		logger.info(builderObj.toString());
	}
	
	private void runPatchUnderSqlFolder(Connection connObj, List<String> fileList) throws SQLException, URISyntaxException, IOException {
		SingleFileResourceUtils sfru = new SingleFileResourceUtils();
		ScriptRunner runner = new ScriptRunner(connObj);
		for(String fileName : fileList) {
			logger.info("=======run sql/" + fileName );	
//			runner.runScript(new BufferedReader(new FileReader(sfru.getFileFromResource("sql/" + fileName))));
			runner.runScript(new InputStreamReader(sfru.getFileFromResourceAsStream("sql/" + fileName)));
			logger.info("=======sql/" + fileName + " run successfully.");	
		}
	}
	
	private Connection getDBConnection() throws SQLException, Exception {
			Class.forName(JDBC_DRIVER);
			return DriverManager.getConnection(JDBC_DB_URL, JDBC_USER, JDBC_PASS);
	}
	
	private List<PatchHistory> getPatchHistory(Connection connObj) throws SQLException {
		 List<PatchHistory> result = new ArrayList<>();
		 Statement stmtOBj = connObj.createStatement();
		 ResultSet rs = stmtOBj.executeQuery("SELECT id, status, version, version, date_applied FROM NURX.patches order by date_applied desc");
		 while (rs.next()) {
			 PatchHistory rh = new PatchHistory();
			 rh.setStatus(rs.getString("status"));
			 rh.setVersion(rs.getString("version"));
			 rh.setId(rs.getInt("id"));
             rh.setDateApplied(rs.getDate("date_applied"));
             result.add(rh);
		}
		return result;
	}
	
	private PatchHistory getLatestPatchHistory(NurxPatchFileRunner nurxPatchRunner, Connection connObj) throws
	    SQLException, Exception {
		PatchHistory result = new PatchHistory();
	    Statement stmtOBj = connObj.createStatement();
	    ResultSet rs = stmtOBj.executeQuery("SELECT id, status, version, version, date_applied FROM NURX.patches order by date_applied desc limit 1");
		while (rs.next()) {
			result.setStatus(rs.getString("status"));
			result.setVersion(rs.getString("version"));
		    logger.info("\n======= Existing Patch Status: " + result.getStatus());
		    logger.info("\n======= Existing Patch Version: " + result.getVersion());
		}
		rs.close();
		return result;
	}
	
	private void applyPatches(NurxPatchFileRunner nurxPatchRunner, Connection connObj, Scanner sc) throws SQLException, Exception{
		PatchHistory latestPatchHistory = nurxPatchRunner.getLatestPatchHistory(nurxPatchRunner, connObj);
		if(DbQueryConstants.LATEST_PATCH_STATUS.equalsIgnoreCase(latestPatchHistory.getStatus())
				&& DbQueryConstants.LATEST_PATCH_VERSION.compareTo(latestPatchHistory.getVersion())>0) {
			System.out.println("Your latest active database does not meet patch requirement.");
			System.out.println("Your will need to upgrade to version Release-1.50.");
			System.out.println("Do you want to continue? Enter 'yes' to continue or 'no' to exit out of patching process!");
			while(sc.hasNext()) {
			    String inputPhrase = sc.nextLine();
			    if(("yes").equals(inputPhrase)) {
					nurxPatchRunner. upgradeTo150(connObj);
			    	break;
			    } else {
			    	System.out.println("Exit out database patching process");
					System.exit(0);
			    }
			}			
		}
		
		latestPatchHistory = nurxPatchRunner.getLatestPatchHistory(nurxPatchRunner, connObj);
		if(DbQueryConstants.LATEST_PATCH_STATUS.equalsIgnoreCase(latestPatchHistory.getStatus())
			&& DbQueryConstants.LATEST_PATCH_VERSION.equalsIgnoreCase(latestPatchHistory.getVersion())) {
			/**
			 * 
			 * Run All Patch Scripts under "sql" folder
			 * 			 
			 * */
			List<String> fileList = Arrays.asList("nurx-ddl.sql", "alter-employees.sql", "alter-employees-after.sql", "populate_employees.sql", "update-patch-history.sql");			
			System.out.println("Your latest active database meet patch requirement.");
			System.out.println("Do you want to continue? Enter 'yes' to continue or 'no' to exit out of patching process!");
			while(sc.hasNext()) {
			    String inputPhrase = sc.nextLine();
			    if(("yes").equals(inputPhrase)) {
					nurxPatchRunner.runPatchUnderSqlFolder(connObj, fileList);
			    	break;
			    } else {
			    	System.out.println("Exit out database patching process");
					System.exit(0);
			    }
			}
//			List<String> fileList = Arrays.asList("nurx-ddl.sql", "alter-employees.sql", "alter-employees-after.sql", "populate_employees.sql");
//			nurxPatchRunner.runPatchUnderSqlFolder(connObj, fileList);
			System.out.println("Your dababase patch completed successfully. Please verify.");
			System.out.println("If you want to rollback this patch, Enter 'yes' to continue or 'no' to exit out of patching process!");
			while(sc.hasNext()) {
			    String inputPhrase = sc.nextLine();
			    if(("yes").equals(inputPhrase)) {
			    	rollbackPatches(connObj);
			    	break;
			    } else {
			    	System.out.println("Exit out database patching process");
					System.exit(0);
			    }
			}
		}
	}
	
	private void rollbackPatches(Connection connObj) throws Exception {
		SingleFileResourceUtils sfru = new SingleFileResourceUtils();
		ScriptRunner runner = new ScriptRunner(connObj);
        String fileName = "rollback.sql";
        logger.info("Rollback =======run sql/" + fileName );	
		runner.runScript(new InputStreamReader(sfru.getFileFromResourceAsStream("sql/" + fileName)));
		logger.info("Rollback =======sql/" + fileName + " run successfully.");	
	}
	
	private void upgradeTo150(Connection connObj) throws Exception {
		SingleFileResourceUtils sfru = new SingleFileResourceUtils();
		ScriptRunner runner = new ScriptRunner(connObj);
        String fileName = "upgrade-to-150.sql";
        logger.info("Upgrade to Release-1.50 =======run sql/" + fileName );	
		runner.runScript(new InputStreamReader(sfru.getFileFromResourceAsStream("sql/" + fileName)));
		logger.info("Upgrade to Release-1.50 =======sql/" + fileName + " run successfully.");	
	}
}